clc;
clear all;
close all;

%% Initializing Variables
N = 200
W = [1;-2;0.5];
x = -5 + 10*rand(N,1)
X = [ones(N,1),x,x.*x]

%% 1a. Calculation of T
    
    % T is a column vector containing all the values of t corresponding to the
    % 200 individual values of x.
n = normrnd(0,1,N,1)
T = X*W + n

%% 1b. (i) Fitting Linear Model 

    % W_Hat = (X.T * X)^-1*X.T*T

X_Lin = [ones(N,1),x]
W_hat_Lin = ((transpose(X_Lin)*X_Lin)\transpose(X_Lin))*T
pred_Lin = X_Lin*W_hat_Lin + normrnd(0,1,N,1)

%Plotting the Values
figure(Name='Linear Model')
scatter(x,pred_Lin,10,'filled','diamond')
hold on
scatter(x,T,10,'filled','square')
legend('Linear Model','Actual Value')
title('Linear Model')

%% 1b. (ii) Fitting Quadratic Model

X_Quad = [ones(N,1),x,x.*x]
W_hat_Quad = (transpose(X_Quad)*X_Quad)\transpose(X_Quad)*T
pred_Quad = X_Quad*W_hat_Quad + normrnd(0,1,N,1)

%Plotting The Values
figure(Name='Quadratic Model')
scatter(x,pred_Quad,10,"filled","diamond")
hold on
scatter(x,T,10,"filled","square")
legend('Quadratic Model','Actual Value')
title('Quadratic Model')



