clc; 
clear all;close all;
%% Load Data + Initialization
load('Olympic.mat')
K = 5;

%% Rescale xn and build the X matrix
xn = xn - xn(1);
xn = xn./4;
X = [ones(size(xn)),xn];
% Comment out the following line for linear
X_Quad = [X xn.^2 xn.^3 xn.^4];

%% Randomize data

n = length(xn);
order = randperm(N);
sizes = repmat(floor(N/K),1,K);
sizes( end) = sizes( end) + N-sum(sizes);
sizes = [0 cumsum(sizes)]


%% Linear Model
lambda_lin = 10.^[-12:1:12];
loss = zeros(length(lambda_lin),K+1)
for r = 1:length(lambda_lin)
    for k = 1:K
        % Extract the train and test data
        traindata = X(order,:);
        traint = tn(order);
        testdata = X(order(sizes(k)+1:sizes(k+1)),:);
        testt = tn(order(sizes(k)+1:sizes(k+1)));
        traindata(sizes(k)+1:sizes(k+1),:) = [];
        traint(sizes(k)+1:sizes(k+1)) = [];
        % Fit the model
        w = inv(traindata'*traindata + lambda_lin(r)*eye(size(X,2)))*traindata'*traint;
        % Compute loss on test data
        predictions = testdata*w;
        loss(r,k) = sum((predictions - testt).^2)
    end
    loss(r,K+1) = loss(r,K)/K
end

figure(Name='First Order Model')
plot(lambda_lin,loss(:,end),"Color",'red','LineStyle','-','Marker','.')

[mini,index] = min(loss);

min_lambda_linear = lambda_lin(index)

%% Fourth Order Model

lambda_4th = 10.^[-12:1:12];
loss = zeros(length(lambda_4th),K+1)
for r = 1:length(lambda_4th)
    for k = 1:K
        % Extract the train and test data
        traindata = X_Quad(order,:);
        traint = tn(order);
        testdata = X_Quad(order(sizes(k)+1:sizes(k+1)),:);
        testt = tn(order(sizes(k)+1:sizes(k+1)));
        traindata(sizes(k)+1:sizes(k+1),:) = [];
        traint(sizes(k)+1:sizes(k+1)) = [];
        % Fit the model
        w = inv(traindata'*traindata + lambda_4th(r)*eye(size(X_Quad,2)))*traindata'*traint;
        % Compute loss on test data
        predictions = testdata*w;
        loss(r,k) = sum((predictions - testt).^2)
    end
    loss(r,K+1) = loss(r,K)/K
end

figure(Name='Fourth Order Model')
plot(lambda_4th,loss(:,end),"Color",'red','LineStyle','-','Marker','.')

[mini,index] = min(loss);

min_lambda_4th = lambda_4th(index)


