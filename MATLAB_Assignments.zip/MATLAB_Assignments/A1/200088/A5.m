clc;
clear all;
close all;

%% Initializing Values (a)

N = 100
x = sort(-5 + 10 * rand(N,1))
X = [ones(N,1),x,x.^2,x.^3]
w = [0;1;-1;5]
T = X*w + normrnd(0,sqrt(300),N,1)

%% Linear Model

X_Lin = [ones(N,1),x]
w_hat_Lin = ((transpose(X_Lin)*X_Lin)\transpose(X_Lin))*T
mu_Lin = X_Lin*w_hat_Lin
var_Lin = (transpose(T - X_Lin*w_hat_Lin)*(T - X_Lin*w_hat_Lin))/N
T_Pred_Lin = X_Lin*w_hat_Lin + transpose(mvnrnd(zeros(N,1),var_Lin * eye(N,N)))
err_Lin = var_Lin * ones(100,1)
figure(Name="Linear Fit")
scatter(x,T)
hold on
errorbar(x,T_Pred_Lin,sqrt(err_Lin),"Marker",".",LineStyle="none")
legend("Actual Data","Linear Fit")

%% Cubic Model

X_cubic = [ones(N,1),x,x.^2,x.^3]
w_hat_cubic = ((transpose(X_cubic)*X_cubic)\transpose(X_cubic))*T
mu_cubic = X_cubic*w_hat_cubic
var_cubic = (transpose(T - X_cubic*w_hat_cubic)*(T - X_cubic*w_hat_cubic))/N
T_Pred_cubic = X_cubic*w_hat_cubic + transpose(mvnrnd(zeros(N,1),var_cubic * eye(N,N)))
err_cubic = var_cubic * ones(100,1)
figure(Name="Cubic Fit")
scatter(x,T)
hold on
errorbar(x,T_Pred_cubic,sqrt(err_cubic),"Marker",'.','LineStyle','none')
legend("Actual Data","Cubic Fit")

%% Sixth Order Model

X_six = [ones(N,1),x,x.^2,x.^3,x.^4,x.^5,x.^6]
w_hat_six = ((transpose(X_six)*X_six)\transpose(X_six))*T
mu_six = X_six*w_hat_six
var_six = (transpose(T - X_six*w_hat_six)*(T - X_six*w_hat_six))/N
T_Pred_six = X_six*w_hat_six + transpose(mvnrnd(zeros(N,1),var_six * eye(N,N)))
err_six = var_six * ones(100,1)
figure(Name="Sixth Order Fit")
scatter(x,T)
hold on
errorbar(x,T_Pred_six,sqrt(err_six),"LineStyle",'none','Marker','.')
legend("Actual Data","Sixth Order Fit")