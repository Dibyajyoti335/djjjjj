clc;
clear all;
close all;

%% Initializing Variables
mu = [2,1]
Cov_a = eye(2,2)
Cov_b = [1,0.8 ; 0.8,1]
x1 = -5:0.25:5  %Uniform set of values between -5 and 5
x2 = x1
[X1,X2] = meshgrid(x1,x2)   % Creates a set of coordinates
X = [X1(:),X2(:)]   %X1(:) prints it out column order, we now have a set of points

%% Part (a)

% Plotting PDF

Y = mvnpdf(X,mu,Cov_a)  
Y = reshape(Y,length(x2),length(x1))
figure(Name="2-D Gaussian PDF(a)")
surf(x1,x2,Y)

% Plotting Contour
figure(Name="2-D Gaussian Contour(a)")
contour(x1,x2,Y)

%% Part (b)

% Plotting PDF
Y1 = mvnpdf(X,mu,Cov_b)  
Y1 = reshape(Y1,length(x2),length(x1))
figure(Name="2-D Gaussian PDF(b)")
surf(x1,x2,Y1)

% Plotting Contour
figure(Name="2-D Gaussian Contour(b)")
contour(x1,x2,Y1)
