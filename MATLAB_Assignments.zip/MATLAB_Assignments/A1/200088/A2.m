clc;
clear all;
close all;

%% Initialization
N = 6
x = sort(rand(N,1))
W = [-3;2]

%% 2a. Dataset Generation
X = [ones(N,1),x]
T = X*W + normrnd(0,sqrt(3),N,1)

%% 2b. Prediction for Different Values of lambda
X_5th_Order = [ones(6,1),x,x.^2,x.^3,x.^4,x.^5]
W_L0 = (transpose(X_5th_Order)*X_5th_Order)^-1*X_5th_Order*T
W_Lminus6 = (transpose(X_5th_Order)*X_5th_Order + N*10^-6*eye(N))^-1*X_5th_Order*T
W_L001 = (transpose(X_5th_Order)*X_5th_Order + N*0.01*eye(N))^-1*X_5th_Order*T
W_L01 = (transpose(X_5th_Order)*X_5th_Order + N*0.1*eye(N))^-1*X_5th_Order*T

T_L0 = X_5th_Order*W_L0 + normrnd(0,sqrt(3),N,1)
T_Lminus6 = X_5th_Order*W_Lminus6 + normrnd(0,sqrt(3),N,1)
T_L001 = X_5th_Order*W_L001 +normrnd(0,sqrt(3),N,1)
T_L01 = X_5th_Order*W_L01 + normrnd(0,sqrt(3),N,1)

%% 2c. Plotting Different Values
plot(x,T,"Color",'red')
hold on
plot(x,T_L0,'Color','blue')
hold on
plot(x,T_Lminus6,'Color','green')
hold on
plot(x,T_L001,"Color","black")
hold on
plot(x,T_L01,'Color','cyan')
hold on
legend('actual','0','10^-6','0.01','0.1')
