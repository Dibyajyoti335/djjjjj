clc;
close all;

%% Q1. Generation of Dataset

N = 500;
mu_1 = [3;3];
mu_2 = [1;-3];
cov_1 = [1 0;0 2];
cov_2 = [2 0;0 1];

select_component = unidrnd(10,1,N);     %Generate a uniformly distributed random array of 500 integers between 1 and 10

X = zeros(N,2);
Cluster_Dataset_1 = zeros(N,2);
Cluster_Dataset_2 = zeros(N,2);
i1=1;
i2=1;

for i = 1:N
    
    if select_component(1,i)>2          %Select Cluster 1 when select_component(i)>2, i.e, with a probability 0.8
        X(i,:) = mvnrnd(mu_1.',cov_1);
        Cluster_Dataset_1(i1,:) = X(i,:);
        i1 = i1 + 1;
    elseif select_component(1,i)<=2     %Select Cluster 2 when select_component(1)<=2, i.e, with probability 0.2
        X(i,:) = mvnrnd(mu_2.',cov_2);
        Cluster_Dataset_2(i2,:) = X(i,:);
        i2 = i2 + 1;
    end

end

figure("Name", "Dataset")
scatter(X(:,1),X(:,2),"black",".")
title("Dataset")

%% Q2. Expectation - Maximization Algorithm

% Intitialization of parameters
K = 2;

pi = repmat([0.5],1,K); % [pi_1 pi_2]

mu = normrnd(0,2,2,K); % [mu_1 mu_2]

Sigma = zeros(2,2,K);
for i=1:K
    Sigma(:,:,i) = eye(2,2);
end


qnk = rand(N,K);
for i = 1:N
    qnk(i,:) = qnk(i,:)/sum(qnk(i,:));
end

% Variables for Updated Parameters
pi_new = zeros(1,K);
mu_new = zeros(2,K);
Sigma_new = zeros(2,2,K);
qnk_new = zeros(N,K);
lower_bound_values = [];
number_of_iterations = 500;

f = waitbar(0,"Calculating...","Name","Loading");
%We run this for 500 iterations, and break if convergence is obtained before that
for i=1:number_of_iterations
    waitbar(i/number_of_iterations,f,"Calculating...")
    for j=1:K
        
        qnj = qnk(:,j);
        qnj_sum = sum(qnj);
        pi_new(:,j) = qnj_sum/N;

        qnjxn = X.*qnj;
        mu_new(:,j) = sum(qnjxn)/qnj_sum;

        covj_new_numerator = zeros(2,2);

        for p = 1:N
            xp_minus_muj = X(p,:).' - mu(:,j);
            outer_product = xp_minus_muj * xp_minus_muj.';
            covj_new_numerator = covj_new_numerator +  qnj(p).*outer_product;

            qnk_new(p,j) = pi(:,j) * mvnpdf(X(p,:),mu(:,j).',Sigma(:,:,j));
            
            
        end

        covj_new = covj_new_numerator/qnj_sum;
        Sigma_new(:,:,j) = covj_new;
    end

    for j=1:N
        qnk_new(j,:) = qnk_new(j,:)/sum(qnk_new(j,:));
    end
    
    pi = pi_new;
    mu = mu_new;
    Sigma = Sigma_new;
    qnk = qnk_new;

    lower_bound_values(i,:) = [i,lower_bound(qnk,pi,X,mu,Sigma,N,K)];

    if(i>1)
        if (abs(lower_bound_values(i,2)-lower_bound_values(i-1,2))==0) %if lower bound hasnt changed from previous iteration
            fprintf("Lower Bound has Converged in %d iterations",i);
            break;
        end
    end

   

 

end

waitbar(1,f,"Calculating...")
pause(0.5);
close(f)

pi
mu
Sigma

%% Q3. Assignment of dataset points to clusters

cluster_pred_1 = [];
i1=1;
cluster_pred_2 = [];
i2=1;

for i=1:N
    
    if qnk(i,1)>qnk(i,2)
        cluster_pred_1(i1,:) = X(i,:);
        i1 = i1 + 1;
    else
        cluster_pred_2(i2,:) = X(i,:);
        i2 = i2 + 1;
    end

end

x1 = -5:0.25:5;
x2 = x1;
[X1,X2] = meshgrid(x1,x2);
X_points = [X1(:),X2(:)];


figure("Name","Clustered Dataset")

scatter(cluster_pred_1(:,1),cluster_pred_1(:,2),"blue",".");
hold on
Y = mvnpdf(X_points,mu(:,1).',Sigma(:,:,1));
Y = reshape(Y,length(x2),length(x1));
%contour(x1,x2,Y);      %uncomment for Contour plot
scatter(cluster_pred_2(:,1),cluster_pred_2(:,2),"red",".");
Y = mvnpdf(X_points,mu(:,2).',Sigma(:,:,2));
Y = reshape(Y,length(x2),length(x1));
%contour(x1,x2,Y);      %uncomment for Contour plot
hold off
title("Clustered Dataset")

figure("Name", "Lower Bound Trend");
plot(lower_bound_values(:,1),lower_bound_values(:,2));
xlabel("Iteration No.");
ylabel("Lower Bound Value");

%% Lower Bound Function

function b = lower_bound(qnk, pi, X, mu, Sigma, N, K)
    sum_1 = 0;
    sum_2 = 0;
    sum_3 = 0;
    for i = 1:N
        for j = 1:K
            sum_1 = sum_1 + qnk(i,j)*log(pi(j));
            sum_2 = sum_2 + qnk(i,j)*log(mvnpdf(X(i,:),mu(:,j).',Sigma(:,:,j)));
            sum_3 = sum_3 + qnk(i,j)*log(qnk(i,j));
        end
    end
    
    b = sum_1 + sum_2 - sum_3;
        
end
