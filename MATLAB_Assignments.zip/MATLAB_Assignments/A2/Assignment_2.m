clc;
close all;

%%  Generating Synthetic Data

N = 20
M = 40
D0 = 7
phi = normrnd(0,1,N,M)
w = [normrnd(0,1,D0,1);zeros(M-D0,1)]
w = w(randperm(M))
var = [-20 -15 -10 -5 0]
var = arrayfun(@(x) inverse_db(x),var)
t = zeros(N,length(var))
for i = 1:length(var)
    t(:,i) = phi*w + normrnd(0,sqrt(var(i)),N,1); % 5 columns each containing values of t for different variances   
end

%% Sparse Bayesian Learning : -20dB
t1 = t(:,1)
alpha1 = normrnd(2,1,M,1)
var1 = normrnd(3,1,1)
for i = 1:40
    A = diag(alpha1);
    sigmainv = (((var1^-1)*(phi' * phi))+A);
    mu = (1/var1)*(sigmainv\phi'*t1);
    diag_sigma = diag(inv(sigmainv));
    gamma = ones(length(diag_sigma),1) - alpha1.*diag_sigma;
    alpha1 = gamma./(mu.*mu);
    numerator = (norm(t1 - phi*mu))^2;
    denominator = N - sum(gamma);
    var1 = numerator/denominator;
end

mu1 = (1/var1)*(sigmainv\phi'*t1)

%% Sparse Bayesian Learning : -15dB
t2 = t(:,2)
alpha2 = normrnd(2,1,M,1)
var2 = normrnd(3,1,1)
for i = 1:40
    A = diag(alpha2);
    sigmainv = (((var2^-1)*(phi' * phi))+A);
    mu = (1/var2)*(sigmainv\phi'*t2);
    diag_sigma = diag(inv(sigmainv));
    gamma = ones(length(diag_sigma),1) - alpha2.*diag_sigma;
    alpha2 = gamma./(mu.*mu);
    numerator = (norm(t2 - phi*mu))^2;
    denominator = N - sum(gamma);
    var2 = numerator/denominator;
end

mu2 = (1/var2)*(sigmainv\phi'*t2)

%% Sparse Bayesian Learning : -10dB
t3 = t(:,3)
alpha3 = normrnd(0,1,M,1)
var3 = normrnd(3,1,1)
for i = 1:40
    A = diag(alpha3);
    sigmainv = (((var3^-1)*(phi' * phi))+A);
    mu = (1/var3)*(sigmainv\phi'*t3);
    diag_sigma = diag(inv(sigmainv));
    gamma = ones(length(diag_sigma),1) - alpha3.*diag_sigma;
    alpha3 = gamma./(mu.*mu);
    numerator = (norm(t3 - phi*mu))^2;
    denominator = N - sum(gamma);
    var3 = numerator/denominator;
end

mu3 = (1/var3)*(sigmainv\phi'*t3)

%% Sparse Bayesian Learning : -5dB
t4 = t(:,4)
alpha4 = normrnd(2,1,M,1)
var4 = normrnd(3,1,1)
for i = 1:40
    A = diag(alpha4);
    sigmainv = (((var4^-1)*(phi' * phi))+A);
    mu = (1/var4)*(sigmainv\phi'*t4);
    diag_sigma = diag(inv(sigmainv));
    gamma = ones(length(diag_sigma),1) - alpha4.*diag_sigma;
    alpha4 = gamma./(mu.*mu);
    numerator = (norm(t4 - phi*mu))^2;
    denominator = N - sum(gamma);
    var4 = numerator/denominator;
end

mu4 = (1/var4)*(sigmainv\phi'*t4)

%% Sparse Bayesian Learning : 0dB
t5 = t(:,5)
alpha5 = normrnd(2,1,M,1)
var5 = normrnd(3,1,1)
for i = 1:40
    A = diag(alpha5);
    sigmainv = (((var5^-1)*(phi' * phi))+A);
    mu = (1/var5)*(sigmainv\phi'*t5);
    diag_sigma = diag(inv(sigmainv));
    gamma = ones(length(diag_sigma),1) - alpha5.*diag_sigma;
    alpha5 = gamma./(mu.*mu);
    numerator = (norm(t5 - phi*mu))^2;
    denominator = N - sum(gamma);
    var5 = numerator/denominator;
end

mu5 = (1/var5)*(sigmainv\phi'*t5)

%% Plotting The NMSE Graph

nmse1 = NMSE(mu1,w)
nmse2 = NMSE(mu2,w)
nmse3 = NMSE(mu3,w)
nmse4 = NMSE(mu4,w)
nmse5 = NMSE(mu5,w)

NMSE_ARR = [nmse1 nmse2 nmse3 nmse4 nmse5]
variance_arr = {"  -20dB", '  -15dB' ,'  -10dB', '  -5dB', '  0dB'}
figure('Name','NMSE vs. Variance')
plot(var,NMSE_ARR,'Marker','o')
text(var,NMSE_ARR,variance_arr,'VerticalAlignment','top','HorizontalAlignment','left')

function val = inverse_db(x)
    val = 10^(x/10);
end

function nmse = NMSE(x,y)
    nmse = (norm(x-y)/norm(y))^2;
end